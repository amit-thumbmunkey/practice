package com.test;

import java.nio.file.Paths;

import org.assertj.core.api.Assertions;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserType.LaunchOptions;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

public class LaunchBrowser {

	public static void main(String[] args) {

		Playwright playwright = Playwright.create();
		Browser browser = playwright.chromium().launch(new LaunchOptions().setHeadless(false));
		Page page= browser.newPage();
		page.navigate("https://web-dev.awsm-app.co.uk/login");
		page.getByPlaceholder("name@email.com").type("test43@example.com");
		page.getByPlaceholder("Enter password").type("Test@1234");
		page.locator("//*[@id='app']/div/div/main/div/div[1]/div/div[3]/button[1]").click();
	     page.screenshot(new Page.ScreenshotOptions().setPath(Paths.get("example.png")));
        Assertions.assertThat(page.title()).isEqualTo("AWSM Farming");
        page.close();
        browser.close();
        playwright.close();
		
	}

}
