	
	package com.test;

	import java.nio.file.Paths;

	import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType.LaunchOptions;
	import com.microsoft.playwright.Locator;
	import com.microsoft.playwright.Page;
	import com.microsoft.playwright.Playwright;
   
public class PracticePlaywright {
	


			static Playwright playwright;
			static Browser browser;  
			
			BrowserContext context;
			Page page;
			
			@BeforeAll
			static void launchBrowser() {
				playwright = Playwright.create();
				browser = playwright.chromium().launch(new LaunchOptions().setHeadless(false));
				
			}
			
			@AfterAll
			static void closeBrowser() {
				playwright.close();
			}
			
			@BeforeEach
			void createContextPage() {
				context = browser.newContext();
				page = context.newPage();
			}
			
			@AfterEach
			void closeContext() {
				context.close();
			}

			
			@Test
			void Login()
			{
				page.navigate("https://web-dev.awsm-app.co.uk/login");
				page.getByPlaceholder("name@email.com").type("test43@example.com");
				page.getByPlaceholder("Enter password").type("Test@1234");
				page.locator("//*[@id='app']/div/div/main/div/div[1]/div/div[3]/button[1]").click(); 
			     page.screenshot(new Page.ScreenshotOptions().setPath(Paths.get("example.png")));
		        Assertions.assertThat(page.title()).isEqualTo("AWSM Farming");
			}
			
	

}
